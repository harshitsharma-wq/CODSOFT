#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    char playAgain;

    srand(time(0));

    do
    {
        int randomNumber = rand() % 100 + 1;
        int guess;
        int attempts = 0;

        cout << "\n==================================" << endl;
        cout << "     NUMBER GUESSING GAME" << endl;
        cout << "==================================" << endl;

        cout << "\nI have selected a number between 1 and 100." << endl;
        cout << "Try to guess it!" << endl;

        do
        {
            cout << "\nEnter your guess: ";
            cin >> guess;

            attempts++;

            if (guess > randomNumber)
            {
                cout << "Too High! Try Again." << endl;
            }
            else if (guess < randomNumber)
            {
                cout << "Too Low! Try Again." << endl;
            }
            else
            {
                cout << "\nCongratulations!" << endl;
                cout << "You guessed the correct number." << endl;
                cout << "Total Attempts: " << attempts << endl;
            }

        } while (guess != randomNumber);

        cout << "\nDo you want to play again? (Y/N): ";
        cin >> playAgain;

    } while (playAgain == 'Y' || playAgain == 'y');

    cout << "\nThank you for playing!" << endl;

    return 0;
}