#include <iostream>

using namespace std;

int main()
{
    double num1, num2;
    char operation;
    char choice;

    do
    {
        cout << "\n==============================" << endl;
        cout << "      SIMPLE CALCULATOR" << endl;
        cout << "==============================" << endl;

        cout << "\nEnter First Number: ";
        cin >> num1;

        cout << "Enter Second Number: ";
        cin >> num2;

        cout << "\nChoose Operation (+, -, *, /): ";
        cin >> operation;

        switch(operation)
        {
            case '+':
                cout << "\nResult = " << num1 + num2 << endl;
                break;

            case '-':
                cout << "\nResult = " << num1 - num2 << endl;
                break;

            case '*':
                cout << "\nResult = " << num1 * num2 << endl;
                break;

            case '/':
                if(num2 != 0)
                {
                    cout << "\nResult = " << num1 / num2 << endl;
                }
                else
                {
                    cout << "\nError! Division by zero is not allowed." << endl;
                }
                break;

            default:
                cout << "\nInvalid Operation!" << endl;
        }

        cout << "\nDo you want to perform another calculation? (Y/N): ";
        cin >> choice;

    } while(choice == 'Y' || choice == 'y');

    cout << "\nThank you for using the Calculator!" << endl;

    return 0;
}